# Florentis GitHub Pages 上線說明

## 資料夾內容
- `index.html`：首頁主檔
- `assets/hero-qixingtan.png`：首頁主視覺
- `assets/logo-awanaing.jpg`：品牌 Logo

## 上傳到 GitHub Pages
1. 進入你的 GitHub repository。
2. 將 `index.html` 與 `assets` 資料夾整個上傳到 repo 根目錄。
3. 到 `Settings` → `Pages`。
4. Source 選 `Deploy from a branch`。
5. Branch 選 `main` / `/root`。
6. 儲存後等待 1～3 分鐘，GitHub Pages 就會生成網站。

## 目前仍需你補上的資訊
- 銀行代碼／銀行名稱
- 銀行帳號

請在 `index.html` 搜尋：
- `請補上正式資訊`

把這兩個欄位換成你的正式收款資訊即可。

## 本版已完成的更新
- 所有「創始員」改為「創始源」
- 依指定更新各班按鈕文案與表單連結
- 刪除「主視覺與網頁美化方向」區塊
- 報名流程刪除第 4 點
- 課程包含時數改為 `12~16 小時`
- 「PI-STONE / 個人能量錨」改為「能量環」
- 「社群」改為「線上社群權限」
- 「儀式」相關文字已改為較符合法規的「共振 / 體驗 / 整理」描述
